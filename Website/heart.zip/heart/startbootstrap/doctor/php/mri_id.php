<?php
	session_start();
	$_SESSION['MRI_id'] = $_POST['id'];
	
?>